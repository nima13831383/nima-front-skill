# ANTI_AI_UI_REVIEW Checklist

Use this as an evidence checklist, not a ban list. “References are evidence, not templates.” Note context when a pattern is justified and report only material findings.

## Composition and structure

- Generic SaaS hero: giant centered headline, paragraph, and two CTA buttons.
- Predictable startup landing-page structure used without a product-specific reason.
- Unnecessary badge or eyebrow above every headline.
- Perfect symmetry where asymmetry would better express content or action.
- Every section reduced to a three-column feature grid.
- Every idea placed inside an identical card.
- Floating dashboard mockup used by default rather than because the product needs it.
- Fake dashboard decoration that communicates no real product state or task.
- Repeated icon + heading + paragraph feature blocks used as the page’s only composition.
- Monotonous section rhythm or excessive whitespace without composition.
- Layout reads like a component-library showcase, Tailwind landing-page template, or shadcn demo.

## Surface and visual language

- Unmotivated purple/blue gradients, glowing blobs, or gradient text.
- Too many visual effects competing simultaneously without semantic purpose.
- Excessive glassmorphism, blur, translucent panels, or drop shadows.
- Excessive rounded rectangles or pill-shaped controls.
- One radius, border, and shadow treatment applied to every hierarchy level.
- Repeated icon-in-colored-circle treatment.
- Random decorative illustrations or visual motifs that do not belong to the subject.
- Generic icon library output with no sizing, stroke, or placement decisions.

## Content and credibility

- Generic startup copy that could describe any product.
- Fake testimonials, meaningless metrics, or unsupported social proof.
- Decorative labels, number markers, or meta strings that add no information.
- Copy that sounds like a template rather than the user’s domain and audience.

## Typography and hierarchy

- Generic Inter/Roboto choice without a contextual reason.
- Excessive all-caps, tracked labels, or single-word accenting as decoration.
- Weak hierarchy, indistinguishable text levels, poor line length, or awkward wraps.
- Typography treated as neutral delivery instead of part of the visual identity.

## Motion and interaction

- Independent fade-up animation on every section or card.
- Hover transforms on non-interactive or already-obvious elements.
- Motion everywhere instead of one or two purposeful moments.
- Missing reduced-motion behavior or motion that obscures hierarchy.

## Responsive and system coherence

- Desktop-only composition, brittle fixed widths, overflow, or broken mobile hierarchy.
- Inconsistent visual hierarchy between viewports.
- Inconsistent borders, radii, shadows, or spacing tokens.
- CTA prominence that changes accidentally at smaller widths.
- Art direction that changes arbitrarily from one section to the next.

## Output contract and prioritization

Start the report with:

`ANTI_AI_UI_REVIEW`

`Design coherence:`

`Generic-pattern findings:`

For each finding, use:

- Issue
- Evidence
- Why it feels generic
- Severity: high / medium / low
- Correction

Then provide:

`Highest-impact changes:`

1. 
2. 
3. 

Prioritize issues that affect the first impression, overall composition, typography, or repeated system patterns. Prefer a few high-leverage corrections—such as changing the hero composition, reducing card repetition, or establishing a distinctive type/palette relationship—over many cosmetic tweaks.
