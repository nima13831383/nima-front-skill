---
name: anti-ai-ui-review
description: Critique an implemented or rendered frontend for generic, template-like AI aesthetics and produce a focused ANTI_AI_UI_REVIEW without becoming a generic bug checker.
metadata:
  short-description: Find and correct generic AI-looking interface patterns
---

# Anti-AI UI Review

Use this skill after a frontend has been implemented or rendered, normally after `visual-qa`. Judge the interface as a designed product, not as a collection of technically valid components. This is a focused design-critic pass, not generic bug checking, accessibility auditing, or implementation review.

## Review method

1. Inspect the rendered interface at the available desktop and mobile states. Use screenshots/browser inspection as the primary evidence; use source only to explain a visible issue or locate its likely cause.
2. Compare the interface with the project brief and any `ART_DIRECTION_BRIEF`. Ask of each candidate pattern: “Does this decision appear to come from the project’s visual concept, or from a generic frontend-generator default?”
3. Judge context, not isolated components. A centered hero, gradient, rounded card, or Inter font is not inherently wrong; unconsidered default usage is the concern.
4. Produce the exact `ANTI_AI_UI_REVIEW` format in [the review checklist](references/anti-ai-ui-review-checklist.md). For each finding use **Issue**, **Evidence**, **Why it feels generic**, **Severity** (high, medium, or low), and **Correction**.
5. Report only the few findings with material design impact—normally no more than three to five unless the user requests an exhaustive audit. End with the highest-impact changes in priority order. Do not rewrite the application or edit files unless the user explicitly requests fixes.

Use the detailed anti-pattern catalog in [the review checklist](references/anti-ai-ui-review-checklist.md). Inspect aggressively for generic SaaS heroes, purple/blue gradients and glow blobs, glassmorphism, rounded/pill saturation, card-grid repetition, repeated icon circles, default dashboard mockups, symmetry without purpose, empty composition, unmotivated Inter/Roboto, uncustomized icon libraries, gradient text, excess shadows, decorative badges, fake testimonials or metrics, startup copy, filler illustrations, scattered fade-up motion, gratuitous hover transforms, inconsistent hierarchy, desktop-only thinking, and shadcn/Tailwind/component-demo sameness.

## False-positive guardrail

Do not flag a component merely because it is common. Ask whether its shape, density, copy, hierarchy, and behavior are intentional for the product, and whether the same pattern would plausibly have been chosen for five unrelated briefs. A restrained, context-appropriate card or pill can pass; a repeated default kit should not.

The normal stack order is:

`User brief → design-reference-analyzer → art-direction → frontend-design → implementation → visual-qa → anti-ai-ui-review → targeted visual refinement → visual-qa again`

Routing: use `visual-qa → anti-ai-ui-review` for an existing page critique. After implementation, use `browser-runtime-inspector → visual-qa → anti-ai-ui-review` when browser access is available, then run `visual-qa` again after targeted corrections. Do not activate the full design pipeline for a small bug fix.

This skill is independently usable for an existing interface even when no prior art direction exists; state that the review is calibrated from the rendered product and user context.
