---
name: art-direction
description: Define an intentional, context-aware visual direction before frontend implementation, translating project context and optional design references into a concrete ART_DIRECTION_BRIEF.
metadata:
  short-description: Set a deliberate visual direction before implementation
---

# Art Direction

Use this skill before frontend implementation whenever visual design is important, except for small isolated bug fixes that do not change the design direction. It turns a project brief and, when available, a `DESIGN_REFERENCE_BRIEF` into an actionable `ART_DIRECTION_BRIEF` that `frontend-design` and the implementer can follow. It does not write the full frontend implementation.

## Required process

1. Establish the product/site context, audience, primary task, content reality, platform, and constraints. If a key input is missing, make a clearly labeled working assumption or ask only when the missing answer would change the direction materially.
2. Read any `DESIGN_REFERENCE_BRIEF` as input. References are evidence, not templates: carry over transferable principles, reinterpret brand-specific material, and reject direct cloning.
3. Choose a visual concept that makes sense for the context. Direction labels such as editorial, industrial, Japanese minimal, brutalist, luxury editorial, utilitarian, typography-led, image-led, experimental, or retro-futurist are options—not defaults. Never use “modern,” “clean,” “premium,” or “futuristic” without translating them into observable choices.
4. Write the exact `ART_DIRECTION_BRIEF` format using [the required template](references/art-direction-template.md). It must define: Product, Audience, Primary task, Visual concept, Design personality, Reference influences, Typography direction, Layout philosophy, Color philosophy, Image treatment, Spacing rhythm, Shape language, Interaction philosophy, Motion philosophy, Memorable visual device, and Explicitly avoided patterns.
5. Review the direction against the brief. Each major decision should have a reason tied to audience, subject matter, content, or platform. Keep one memorable device and let the rest of the system support it with restraint.

## Precedence and implementation gate

When instructions conflict, use: user requirements → existing product/brand system → `ART_DIRECTION_BRIEF` → `DESIGN_REFERENCE_BRIEF` → `frontend-design` principles → `ui-ux-pro-max` generic recommendations. Accessibility and functional usability requirements override aesthetics.

Do not hand off to implementation until the direction gives concrete guidance on type roles, palette behavior, composition, density, imagery, shape, interaction, motion, and responsive intent. Include accessible contrast, visible focus, reduced-motion behavior, and mobile behavior in the direction rather than treating them as a later patch.

The normal stack handoff is:

`User brief → design-reference-analyzer → art-direction → frontend-design → implementation → visual-qa → anti-ai-ui-review → targeted visual refinement → visual-qa again`

Routing: with references, use `design-reference-analyzer → art-direction → frontend-design`; without references, use `art-direction → frontend-design`. For a new dashboard, analyzer is optional unless references exist. For a small button or CSS bug fix, do not activate the full pipeline.

This skill is independently usable when no reference exists; derive the direction from the product context and explicitly note assumptions.
