# ART_DIRECTION_BRIEF

Product:
Audience:
Primary task:
Visual concept:
Design personality:
Reference influences:
Typography direction:
Layout philosophy:
Color philosophy:
Image treatment:
Spacing rhythm:
Shape language:
Interaction philosophy:
Motion philosophy:
Memorable visual device:
Explicitly avoided patterns:

## Handoff acceptance

- [ ] Decisions are concrete and context-specific.
- [ ] References were translated, not cloned.
- [ ] Responsive, accessible, and reduced-motion intent is present.
- [ ] The memorable device is singular and supportable.
- [ ] The brief is sufficient for another agent to implement without inventing the visual direction.
