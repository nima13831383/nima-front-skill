---
name: visual-qa
description: Inspect rendered frontend interfaces in a real browser across relevant viewports and produce an objective VISUAL_QA_REPORT of visual and responsive defects.
metadata:
  short-description: Verify rendered frontend layout across real viewports
---

# Visual QA

Use this skill after frontend implementation or a targeted visual change, and again after visual refinement. Inspect what a user can actually see; source inspection, compilation, tests, Lighthouse, and a clean console are supporting signals, not visual proof. This skill owns rendered visual QA, not general runtime debugging or subjective anti-AI criticism.

## Runtime workflow

1. Identify the application’s documented start command and run it when a local app is in scope. Do not change application source or install dependencies as part of an audit unless the user explicitly asks for fixes or setup.
2. When browser access is available, use `browser-runtime-inspector` first for launch, console/page errors, DOM state, computed styles, interaction states, geometry, stacking, and screenshot acquisition. `visual-qa` then owns the visual defect verdict and responsive comparison.
3. Open the relevant route in the available browser. Prefer real-browser interaction and runtime inspection when available. If a browser or screenshot capability is unavailable, report that limitation rather than claiming visual success.
3. Capture and inspect a desktop view plus tablet and mobile views when the layout is responsive or the target audience uses those devices. Exercise important navigation, menu, form, loading, empty, error, sticky, and overlay states when relevant.
4. Review the evidence against [the QA checklist and report format](references/visual-qa-checklist-and-report.md). Inspect spacing, alignment, overflow, clipping, wrapping, hierarchy, contrast, section rhythm, image crops, borders, radii, shadows, density, navigation, CTA prominence, fixed elements, layout shifts, balance, and horizontal scrolling.
5. Produce the exact `VISUAL_QA_REPORT` format. Separate objective visual defects from subjective design suggestions, and include viewport/state evidence, severity, impact, likely cause when known, and an actionable fix. Distinguish observed defects from unverified concerns.
6. When the visual pass is complete, hand the rendered evidence to `anti-ai-ui-review` for a separate genericness/design-critique pass. After targeted refinement, run this visual QA again with fresh screenshots.

## Pass criteria

Do not call the design successful merely because it compiles, tests pass, Lighthouse passes, or no console errors appear. A pass requires that the rendered interface is visually inspectable, responsive at relevant widths, readable, aligned, free of unintended overflow/clipping, and coherent with the product’s art direction. Accessibility and reduced-motion behavior are part of visual quality.

The normal stack order is:

`User brief → design-reference-analyzer → art-direction → frontend-design → implementation → visual-qa → anti-ai-ui-review → targeted visual refinement → visual-qa again`

Routing: use `visual-qa` alone for a CSS overflow or visual bug when browser inspection is enough; use `visual-qa → anti-ai-ui-review` for an existing page critique. Do not activate the full design pipeline for small fixes. Stop after one or two meaningful refinement passes unless the user explicitly requests more iteration; do not enter an infinite polish loop.

This skill is independently usable for a rendered frontend when no reference or art direction exists; calibrate findings against the user’s brief and clearly state the missing design contract.
