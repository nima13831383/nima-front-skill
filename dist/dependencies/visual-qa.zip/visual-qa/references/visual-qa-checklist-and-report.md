# VISUAL_QA_REPORT Checklist and Report

## Evidence matrix

Record route, viewport, browser, state, screenshot path or reference, and whether the observation is direct or inferred.

| Viewport / state | Evidence captured | Key observations |
| --- | --- | --- |
| Desktop |  |  |
| Tablet |  |  |
| Mobile |  |  |
| Important interaction state(s) |  |  |

## Checklist

- Spacing rhythm, alignment, container widths, and section proportions.
- Overflow, clipping, wrapping, line length, awkward breaks, and horizontal scrolling.
- Typography scale, weight, contrast, hierarchy, and responsive line breaks.
- Visual hierarchy, section rhythm, density, whitespace, and balance.
- Image crop, aspect ratio, loading behavior, and focal point.
- Borders, radii, shadows, surface consistency, and contrast.
- Navigation behavior, menu states, sticky/fixed elements, overlays, and viewport anchoring.
- CTA prominence, touch target clarity, focus visibility, and feedback states.
- Layout shifts, unstable content, and broken loading/empty/error states.
- Reduced-motion behavior and motion that changes or obscures the layout.

## Report format

Start the report with the exact token `VISUAL_QA_REPORT`.

### Overall verdict

- Status: Pass / Pass with issues / Blocked by missing runtime evidence
- Routes and viewports inspected:
- Biggest visual risk:

### Findings

Separate objective visual defects from subjective design suggestions. For each objective issue:

1. **Issue** — concise description.
2. **Evidence** — viewport, state, and screenshot/runtime observation.
3. **Severity** — Critical, High, Medium, or Low.
4. **Impact** — what the user sees or cannot do.
5. **Action** — the smallest concrete correction.
6. **Verification** — how to confirm it on the next fresh capture.

Use these required summary fields when applicable:

Viewport:
Critical issues:
Layout issues:
Responsive issues:
Typography issues:
Spacing/alignment issues:
Image issues:
Interaction issues:
Accessibility-visible issues:
Recommended fixes:

Subjective design suggestions:

### Verification limits

List routes, states, browsers, device sizes, or interactions that could not be inspected. Never silently treat unobserved states as passing.
