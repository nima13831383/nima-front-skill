# DESIGN_REFERENCE_BRIEF

Keep this concise, actionable, and explicit about evidence versus inference.

Reference summary:
Visual principles:
Typography:
Layout:
Grid:
Spacing rhythm:
Color behavior:
Shape language:
Image treatment:
Motion:
Navigation:
Responsive observations:
Distinctive motifs:
Patterns worth borrowing:
Brand-specific elements NOT to copy:
Risks of direct imitation:

## Per-reference notes

When multiple references exist, keep their contributions separate before synthesis.

- Reference A — observed contribution / confidence:
- Reference B — observed contribution / confidence:
- Reference C — observed contribution / confidence:

## Handoff notes for art direction

- Target product/context:
- Decisions requiring reinterpretation:
- Unknowns or open questions:
