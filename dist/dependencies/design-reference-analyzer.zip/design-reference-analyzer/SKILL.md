---
name: design-reference-analyzer
description: Analyze screenshots, images, Figma references, URLs, or existing websites into a concise DESIGN_REFERENCE_BRIEF of transferable design language; do not implement the frontend.
metadata:
  short-description: Extract reusable design language from references
---

# Design Reference Analyzer

Use this skill only when the user supplies a screenshot, image, Figma reference, URL, or existing website and wants its design language understood. Its output is a `DESIGN_REFERENCE_BRIEF` for `art-direction`; it must not implement the frontend or prescribe a direct clone.

## Operating principle

References are evidence, not templates. We are not trying to make unusual designs for their own sake. We are trying to create deliberate, context-aware interfaces with a clear visual point of view. Treat each reference as evidence about design choices, not as a template to copy.

## Workflow

1. Inspect the actual reference. Use image inspection for images and browser/runtime inspection when a live URL is available. Record direct observations separately from inferences, and mark unknown responsive or motion behavior as unknown.
2. When several references exist, analyze each one separately first. Identify what is useful from each—such as typography from A, composition from B, imagery from C, or motion from D—before describing a synthesis.
3. Analyze layout and grid, containers and section proportions, spacing rhythm, typography and font characteristics, density and whitespace, alignment, color behavior, borders, radii, shadows, imagery, icons, navigation, CTAs, motion, responsive behavior, motifs, and distinctive elements.
4. Separate reusable principles from brand-specific material. Reusable principles describe structure, hierarchy, rhythm, or interaction logic. Brand-specific material includes logos, names, proprietary copy, exact illustrations, distinctive photography, trademarked marks, and other elements that should not be copied unless the user owns or explicitly licenses them.
5. Translate observations into concrete choices another designer can apply to a different product. Prefer “use a narrow reading measure with asymmetric supporting metadata” over “make it look like this site.”
6. Produce the exact `DESIGN_REFERENCE_BRIEF` format in [the brief template](references/design-reference-brief-template.md). Include evidence/confidence notes and finish with imitation risks or open questions.

For an exact-reproduction request, preserve structural and visual fidelity to the supplied reference instead of inventing a radically different art direction, while still avoiding protected branding or assets that were not provided or authorized.

## Quality gate

Before handing the brief to `art-direction`, check that every recommendation is traceable to an observed pattern or target context, that multi-reference contributions remain distinguishable, that brand-specific elements are clearly fenced off, and that the brief contains actionable decisions rather than adjectives.

The normal stack handoff is:

`User brief → design-reference-analyzer → art-direction → frontend-design → implementation → visual-qa → anti-ai-ui-review → targeted visual refinement → visual-qa again`

If no visual reference is supplied, skip this skill and use `art-direction` directly. For reference analysis only, stop after producing the brief.
